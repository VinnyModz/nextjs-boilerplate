import Link from 'next/link';
import Image from 'next/image';
import { profileData } from '@/lib/profile-data';
import { Header } from '@/components/header';
import { Footer } from '@/components/footer';
import { TechStack } from '@/components/tech-stack';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Code2, Sparkles, FolderKanban, Mail, ArrowRight } from 'lucide-react';
import { ScrollReveal } from '@/components/scroll-reveal';

export default function HomePage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1">
        <section className="relative overflow-hidden py-20 lg:py-32">
          <div className="absolute inset-0 bg-gradient-to-b from-primary/5 via-transparent to-transparent" />
          
          <div className="container mx-auto px-4 sm:px-6 lg:px-8 relative">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div className="space-y-8 text-center lg:text-left">
                <ScrollReveal delay={100}>
                  {profileData.disponivel && (
                    <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 text-primary border border-primary/20 mx-auto lg:mx-0">
                      <Sparkles className="h-4 w-4" />
                      <span className="text-sm font-medium">Disponível para projetos</span>
                    </div>
                  )}
                </ScrollReveal>

                <ScrollReveal delay={200}>
                  <div className="space-y-4">
                    <h1 className="text-4xl md:text-5xl lg:text-6xl font-bold text-balance leading-tight">
                      Olá, eu sou <span className="bg-gradient-to-r from-primary to-accent bg-clip-text text-transparent">{profileData.nome}</span>
                    </h1>
                    <p className="text-xl md:text-2xl text-muted-foreground font-medium">
                      {profileData.titulo}
                    </p>
                  </div>
                </ScrollReveal>

                <ScrollReveal delay={300}>
                  <p className="text-lg text-muted-foreground text-pretty max-w-2xl leading-relaxed mx-auto lg:mx-0">
                    {profileData.bio}
                  </p>
                </ScrollReveal>

                <ScrollReveal delay={400}>
                  <div className="flex flex-wrap gap-4 justify-center lg:justify-start">
                    <Link href="/projetos">
                      <Button size="lg" className="group">
                        <FolderKanban className="w-5 h-5 mr-2" />
                        Ver Projetos
                        <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                      </Button>
                    </Link>
                    <Link href="/contato">
                      <Button size="lg" variant="outline" className="group">
                        <Mail className="w-5 h-5 mr-2" />
                        Entre em Contato
                      </Button>
                    </Link>
                  </div>
                </ScrollReveal>
              </div>

              <ScrollReveal delay={300}>
                <div className="relative flex items-center justify-center lg:justify-end">
                  <div className="relative w-72 h-72 md:w-96 md:h-96">
                    <div className="absolute inset-0 bg-gradient-to-tr from-primary/20 to-accent/20 rounded-full blur-3xl" />
                    <div className="relative w-full h-full rounded-full overflow-hidden border-4 border-primary/20 shadow-2xl hover:scale-105 transition-transform duration-300">
                      <Image
                        src={profileData.avatar || "/placeholder.svg"}
                        alt={profileData.nome}
                        fill
                        className="object-cover"
                        priority
                      />
                    </div>
                  </div>
                </div>
              </ScrollReveal>
            </div>
          </div>
        </section>

        <section className="py-20 bg-muted/30">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto space-y-16">
              <div>
                <ScrollReveal>
                  <div className="flex items-center justify-center gap-3 mb-8">
                    <Code2 className="h-8 w-8 text-primary" />
                    <h2 className="text-3xl md:text-4xl font-bold">Sobre Mim</h2>
                  </div>
                </ScrollReveal>

                <ScrollReveal delay={200}>
                  <Card className="border-2 hover:border-primary/30 transition-colors">
                    <CardContent className="p-8">
                      <div className="space-y-6">
                        <h3 className="text-2xl font-bold mb-4 text-balance">
                          Olá! Eu sou o <span className="text-primary">{profileData.nome}</span>
                        </h3>
                        <div className="space-y-4 text-muted-foreground leading-relaxed">
                          {profileData.bioCompleta.split('\n\n').map((paragraph, index) => (
                            <p key={index} className="text-pretty">{paragraph}</p>
                          ))}
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </ScrollReveal>
              </div>

              <div>
                <ScrollReveal>
                  <h3 className="text-2xl md:text-3xl font-bold mb-8 text-center">Tecnologias & Habilidades</h3>
                </ScrollReveal>
                <ScrollReveal delay={200}>
                  <TechStack />
                </ScrollReveal>
              </div>
            </div>
          </div>
        </section>

        <section className="py-20">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-2xl mx-auto text-center space-y-6">
              <ScrollReveal>
                <h2 className="text-3xl md:text-4xl font-bold text-balance">
                  Pronto para criar algo incrível?
                </h2>
              </ScrollReveal>
              <ScrollReveal delay={200}>
                <p className="text-lg text-muted-foreground text-pretty">
                  Veja meus projetos e descubra como posso ajudar a transformar suas ideias em realidade
                </p>
              </ScrollReveal>
              <ScrollReveal delay={300}>
                <div className="flex justify-center">
                  <Link href="/projetos">
                    <Button size="lg" className="group">
                      <FolderKanban className="w-5 h-5 mr-2" />
                      Explorar Projetos
                      <ArrowRight className="w-4 h-4 ml-2 group-hover:translate-x-1 transition-transform" />
                    </Button>
                  </Link>
                </div>
              </ScrollReveal>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
