import Link from 'next/link';
import { Header } from '@/components/header';
import { Footer } from '@/components/footer';
import { Button } from '@/components/ui/button';
import { ArrowLeft, FileQuestion } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      
      <main className="flex-1 flex items-center justify-center py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mx-auto text-center space-y-8">
            <div className="space-y-4">
              <div className="flex justify-center">
                <div className="h-24 w-24 rounded-full bg-primary/10 flex items-center justify-center">
                  <FileQuestion className="h-12 w-12 text-primary" />
                </div>
              </div>
              
              <div className="space-y-2">
                <h1 className="text-6xl md:text-7xl font-bold text-balance">404</h1>
                <h2 className="text-2xl md:text-3xl font-semibold text-balance">Página não encontrada</h2>
              </div>
              
              <p className="text-lg text-muted-foreground text-pretty max-w-md mx-auto">
                A página que você está procurando não existe ou foi removida.
              </p>
            </div>

            <div className="flex flex-wrap gap-4 justify-center">
              <Link href="/">
                <Button size="lg" className="group">
                  <ArrowLeft className="mr-2 h-4 w-4 group-hover:-translate-x-1 transition-transform" />
                  Voltar para Home
                </Button>
              </Link>
              <Link href="/projetos">
                <Button size="lg" variant="outline">
                  Ver Projetos
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
