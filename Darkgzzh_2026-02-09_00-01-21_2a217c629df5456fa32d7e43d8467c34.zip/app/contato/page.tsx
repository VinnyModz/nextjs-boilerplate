import { Header } from '@/components/header';
import { Footer } from '@/components/footer';
import { ScrollReveal } from '@/components/scroll-reveal';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { profileData } from '@/lib/profile-data';
import { Github, Mail, MessageCircle, ArrowRight } from 'lucide-react';

export default function ContatoPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 py-12 lg:py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto space-y-12">
            <ScrollReveal>
              <div className="space-y-4 text-center">
                <h1 className="text-4xl md:text-5xl font-bold text-balance">Contato</h1>
                <p className="text-lg text-muted-foreground text-pretty max-w-2xl mx-auto">
                  Entre em contato comigo através das plataformas abaixo. Estou sempre aberto para novos projetos e oportunidades.
                </p>
              </div>
            </ScrollReveal>

            <div className="grid md:grid-cols-2 gap-6">
              {profileData.links.github && (
                <ScrollReveal delay={100}>
                  <Card className="group hover:shadow-xl transition-all duration-300 hover:border-primary/50">
                    <CardHeader className="space-y-4">
                      <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                        <Github className="h-6 w-6 text-primary" />
                      </div>
                      <CardTitle>GitHub</CardTitle>
                      <CardDescription>
                        Veja meus projetos, contribuições e código aberto no GitHub.
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <a href={profileData.links.github} target="_blank" rel="noopener noreferrer">
                        <Button className="w-full group/btn">
                          Abrir GitHub
                          <ArrowRight className="ml-2 h-4 w-4 group-hover/btn:translate-x-1 transition-transform" />
                        </Button>
                      </a>
                    </CardContent>
                  </Card>
                </ScrollReveal>
              )}

              {profileData.links.discord && (
                <ScrollReveal delay={200}>
                  <Card className="group hover:shadow-xl transition-all duration-300 hover:border-primary/50">
                    <CardHeader className="space-y-4">
                      <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                        <MessageCircle className="h-6 w-6 text-primary" />
                      </div>
                      <CardTitle>Discord</CardTitle>
                      <CardDescription>
                        Entre em contato comigo diretamente pelo Discord. Estou sempre disponível para conversar sobre projetos.
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <a href={profileData.links.discord} target="_blank" rel="noopener noreferrer">
                        <Button className="w-full group/btn">
                          Abrir Discord
                          <ArrowRight className="ml-2 h-4 w-4 group-hover/btn:translate-x-1 transition-transform" />
                        </Button>
                      </a>
                    </CardContent>
                  </Card>
                </ScrollReveal>
              )}

              {profileData.links.email && (
                <ScrollReveal delay={300}>
                  <Card className="group hover:shadow-xl transition-all duration-300 hover:border-primary/50 md:col-span-2">
                    <CardHeader className="space-y-4">
                      <div className="h-12 w-12 rounded-full bg-primary/10 flex items-center justify-center group-hover:bg-primary/20 transition-colors">
                        <Mail className="h-6 w-6 text-primary" />
                      </div>
                      <CardTitle>Email</CardTitle>
                      <CardDescription>
                        Envie-me um email para discutir projetos, oportunidades ou apenas para dizer olá.
                      </CardDescription>
                    </CardHeader>
                    <CardContent>
                      <a href={`mailto:${profileData.links.email}`}>
                        <Button className="w-full group/btn">
                          Enviar Email
                          <ArrowRight className="ml-2 h-4 w-4 group-hover/btn:translate-x-1 transition-transform" />
                        </Button>
                      </a>
                    </CardContent>
                  </Card>
                </ScrollReveal>
              )}
            </div>

            <ScrollReveal delay={400}>
              <Card className="bg-muted/50 border-2 border-primary/20">
                <CardContent className="p-8 text-center space-y-4">
                  <h2 className="text-2xl font-bold text-balance">Vamos trabalhar juntos?</h2>
                  <p className="text-muted-foreground text-pretty max-w-xl mx-auto">
                    Se você tem um projeto em mente ou gostaria de discutir oportunidades, não hesite em entrar em contato. Estou sempre interessado em novos desafios e colaborações.
                  </p>
                </CardContent>
              </Card>
            </ScrollReveal>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
