'use client';

import { useState, useEffect } from 'react';
import { useParams } from 'next/navigation';
import Link from 'next/link';
import Image from 'next/image';
import { Header } from '@/components/header';
import { Footer } from '@/components/footer';
import { ScrollReveal } from '@/components/scroll-reveal';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Separator } from '@/components/ui/separator';
import { Project } from '@/lib/types';
import { ArrowLeft, Calendar, ExternalLink, Github, Globe } from 'lucide-react';

export default function ProjetoDetalhePage() {
  const params = useParams();
  const [projeto, setProjeto] = useState<Project | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    async function fetchProjeto() {
      if (!params.slug) {
        setError(true);
        setLoading(false);
        return;
      }

      try {
        const response = await fetch(`/api/projetos/${params.slug}`);
        
        if (!response.ok) {
          setError(true);
          setLoading(false);
          return;
        }

        const data = await response.json();
        setProjeto(data);
        setError(false);
      } catch (err) {
        console.error('Erro ao carregar projeto:', err);
        setError(true);
      } finally {
        setLoading(false);
      }
    }

    fetchProjeto();
  }, [params.slug]);

  if (loading) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 py-12">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-4xl mx-auto space-y-8">
              <Skeleton className="h-12 w-1/2" />
              <Skeleton className="h-96 w-full" />
              <Skeleton className="h-32 w-full" />
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  if (error || !projeto) {
    return (
      <div className="min-h-screen flex flex-col">
        <Header />
        <main className="flex-1 flex items-center justify-center py-20">
          <div className="container mx-auto px-4 sm:px-6 lg:px-8">
            <div className="max-w-2xl mx-auto text-center space-y-6">
              <h1 className="text-4xl font-bold">Projeto não encontrado</h1>
              <p className="text-lg text-muted-foreground">
                O projeto que você está procurando não existe ou foi removido.
              </p>
              <Link href="/projetos">
                <Button size="lg">
                  <ArrowLeft className="mr-2 h-4 w-4" />
                  Voltar para Projetos
                </Button>
              </Link>
            </div>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  const formatDate = (dateString?: string) => {
    if (!dateString) return null;
    return new Date(dateString).toLocaleDateString('pt-BR', {
      year: 'numeric',
      month: 'long',
    });
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 py-12">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-4xl mx-auto space-y-8">
            <ScrollReveal>
              <Link href="/projetos">
                <Button variant="ghost" className="group">
                  <ArrowLeft className="mr-2 h-4 w-4 group-hover:-translate-x-1 transition-transform" />
                  Voltar para Projetos
                </Button>
              </Link>
            </ScrollReveal>

            <ScrollReveal delay={100}>
              <div className="space-y-4">
                <div className="flex flex-wrap items-center gap-3">
                  <Badge variant="secondary" className="capitalize">
                    {projeto.categoria}
                  </Badge>
                  {projeto.status && (
                    <Badge 
                      variant={projeto.status === 'concluido' ? 'default' : 'outline'}
                      className="capitalize"
                    >
                      {projeto.status.replace('-', ' ')}
                    </Badge>
                  )}
                </div>

                <h1 className="text-4xl md:text-5xl font-bold text-balance">{projeto.nome}</h1>
                <p className="text-xl text-muted-foreground text-pretty">{projeto.descricao}</p>

                {(projeto.dataInicio || projeto.dataFim) && (
                  <div className="flex items-center gap-2 text-sm text-muted-foreground">
                    <Calendar className="h-4 w-4" />
                    <span>
                      {formatDate(projeto.dataInicio)}
                      {projeto.dataFim && ` - ${formatDate(projeto.dataFim)}`}
                    </span>
                  </div>
                )}
              </div>
            </ScrollReveal>

            {projeto.imagens && projeto.imagens.length > 0 && (
              <ScrollReveal delay={200}>
                <div className="space-y-4">
                  <div className="relative h-96 w-full rounded-xl overflow-hidden border-2 border-border">
                    <Image
                      src={projeto.imagens[0] || "/placeholder.svg"}
                      alt={projeto.nome}
                      fill
                      className="object-cover"
                      priority
                    />
                  </div>
                  
                  {projeto.imagens.length > 1 && (
                    <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
                      {projeto.imagens.slice(1).map((imagem, index) => (
                        <div key={index} className="relative h-40 rounded-lg overflow-hidden border border-border">
                          <Image
                            src={imagem || "/placeholder.svg"}
                            alt={`${projeto.nome} - ${index + 2}`}
                            fill
                            className="object-cover"
                          />
                        </div>
                      ))}
                    </div>
                  )}
                </div>
              </ScrollReveal>
            )}

            <ScrollReveal delay={300}>
              <Card>
                <CardContent className="p-8 space-y-6">
                  {projeto.descricaoCompleta && (
                    <div className="space-y-4">
                      <h2 className="text-2xl font-bold">Sobre o Projeto</h2>
                      <div className="prose prose-neutral dark:prose-invert max-w-none">
                        {projeto.descricaoCompleta.split('\n\n').map((paragraph, index) => (
                          <p key={index} className="text-muted-foreground leading-relaxed">
                            {paragraph}
                          </p>
                        ))}
                      </div>
                    </div>
                  )}

                  {projeto.tecnologias && projeto.tecnologias.length > 0 && (
                    <>
                      <Separator />
                      <div className="space-y-4">
                        <h2 className="text-2xl font-bold">Tecnologias Utilizadas</h2>
                        <div className="flex flex-wrap gap-2">
                          {projeto.tecnologias.map((tech) => (
                            <Badge key={tech} variant="secondary" className="px-3 py-1 text-sm">
                              {tech}
                            </Badge>
                          ))}
                        </div>
                      </div>
                    </>
                  )}

                  {(projeto.linkGithub || projeto.linkDemo || projeto.linkExterno) && (
                    <>
                      <Separator />
                      <div className="space-y-4">
                        <h2 className="text-2xl font-bold">Links</h2>
                        <div className="flex flex-wrap gap-3">
                          {projeto.linkGithub && (
                            <a href={projeto.linkGithub} target="_blank" rel="noopener noreferrer">
                              <Button variant="outline" className="gap-2">
                                <Github className="h-4 w-4" />
                                Ver no GitHub
                              </Button>
                            </a>
                          )}
                          {projeto.linkDemo && (
                            <a href={projeto.linkDemo} target="_blank" rel="noopener noreferrer">
                              <Button variant="outline" className="gap-2">
                                <Globe className="h-4 w-4" />
                                Ver Demo
                              </Button>
                            </a>
                          )}
                          {projeto.linkExterno && (
                            <a href={projeto.linkExterno} target="_blank" rel="noopener noreferrer">
                              <Button variant="outline" className="gap-2">
                                <ExternalLink className="h-4 w-4" />
                                Link Externo
                              </Button>
                            </a>
                          )}
                        </div>
                      </div>
                    </>
                  )}
                </CardContent>
              </Card>
            </ScrollReveal>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
