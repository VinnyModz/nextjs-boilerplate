'use client';

import { useState, useEffect } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { Header } from '@/components/header';
import { Footer } from '@/components/footer';
import { ScrollReveal } from '@/components/scroll-reveal';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Skeleton } from '@/components/ui/skeleton';
import { Project } from '@/lib/types';
import { Code2, ExternalLink, Globe, Layers } from 'lucide-react';

export default function ProjetosPage() {
  const [projetos, setProjetos] = useState<Project[]>([]);
  const [loading, setLoading] = useState(true);
  const [categoriaAtiva, setCategoriaAtiva] = useState<string>('todos');

  const categorias = [
    { value: 'todos', label: 'Todos', icon: Layers },
    { value: 'bot', label: 'Bots', icon: Code2 },
    { value: 'website', label: 'Websites', icon: Globe },
    { value: 'api', label: 'APIs', icon: Code2 },
  ];

  useEffect(() => {
    async function fetchProjetos() {
      setLoading(true);
      try {
        const params = new URLSearchParams();
        if (categoriaAtiva !== 'todos') {
          params.append('categoria', categoriaAtiva);
        }
        
        const response = await fetch(`/api/projetos?${params}`);
        const data = await response.json();
        setProjetos(data);
      } catch (error) {
        console.error('Erro ao carregar projetos:', error);
      } finally {
        setLoading(false);
      }
    }

    fetchProjetos();
  }, [categoriaAtiva]);

  const getCategoriaIcon = (categoria: string) => {
    const cat = categorias.find(c => c.value === categoria);
    const Icon = cat?.icon || Code2;
    return <Icon className="h-4 w-4" />;
  };

  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-1 py-12 lg:py-20">
        <div className="container mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-6xl mx-auto space-y-12">
            <ScrollReveal>
              <div className="space-y-4 text-center">
                <h1 className="text-4xl md:text-5xl font-bold text-balance">Meus Projetos</h1>
                <p className="text-lg text-muted-foreground text-pretty max-w-2xl mx-auto">
                  Explore meu portfólio de bots, websites e APIs. Cada projeto representa um desafio único e uma solução criativa.
                </p>
              </div>
            </ScrollReveal>

            <ScrollReveal delay={200}>
              <div className="flex flex-wrap justify-center gap-2">
                {categorias.map((categoria) => {
                  const Icon = categoria.icon;
                  const contagem = categoriaAtiva === categoria.value 
                    ? projetos.length 
                    : projetos.filter(p => p.categoria === categoria.value).length;
                  
                  return (
                    <Button
                      key={categoria.value}
                      variant={categoriaAtiva === categoria.value ? 'default' : 'outline'}
                      onClick={() => setCategoriaAtiva(categoria.value)}
                      className="gap-2"
                    >
                      <Icon className="h-4 w-4" />
                      {categoria.label}
                      {!loading && <span className="text-xs opacity-70">({contagem})</span>}
                    </Button>
                  );
                })}
              </div>
            </ScrollReveal>

            {loading ? (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {[1, 2, 3, 4, 5, 6].map((i) => (
                  <Card key={i}>
                    <CardHeader>
                      <Skeleton className="h-48 w-full rounded-md" />
                      <Skeleton className="h-6 w-3/4" />
                      <Skeleton className="h-4 w-full" />
                    </CardHeader>
                  </Card>
                ))}
              </div>
            ) : projetos.length === 0 ? (
              <ScrollReveal delay={300}>
                <Card className="p-12 text-center">
                  <div className="space-y-4">
                    <Code2 className="h-12 w-12 text-muted-foreground mx-auto" />
                    <div>
                      <h3 className="text-xl font-semibold mb-2">Nenhum projeto encontrado</h3>
                      <p className="text-muted-foreground">
                        Não há projetos nesta categoria no momento.
                      </p>
                    </div>
                  </div>
                </Card>
              </ScrollReveal>
            ) : (
              <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
                {projetos.map((projeto, index) => (
                  <ScrollReveal key={projeto._id} delay={index * 100}>
                    <Card className="group hover:shadow-xl transition-all duration-300 hover:border-primary/50 overflow-hidden h-full">
                      <CardHeader className="p-0">
                        {projeto.imagens && projeto.imagens.length > 0 ? (
                          <div className="relative h-48 w-full overflow-hidden bg-muted">
                            <Image
                              src={projeto.imagens[0] || "/placeholder.svg"}
                              alt={projeto.nome}
                              fill
                              className="object-cover group-hover:scale-105 transition-transform duration-300"
                            />
                          </div>
                        ) : (
                          <div className="h-48 w-full bg-gradient-to-br from-primary/20 to-accent/20 flex items-center justify-center">
                            {getCategoriaIcon(projeto.categoria)}
                          </div>
                        )}
                      </CardHeader>
                      <CardContent className="p-6 space-y-4">
                        <div className="space-y-2">
                          <div className="flex items-start justify-between gap-2">
                            <CardTitle className="text-xl group-hover:text-primary transition-colors">
                              {projeto.nome}
                            </CardTitle>
                            <Badge variant="secondary" className="flex items-center gap-1 shrink-0">
                              {getCategoriaIcon(projeto.categoria)}
                              <span className="capitalize text-xs">{projeto.categoria}</span>
                            </Badge>
                          </div>
                          <CardDescription className="line-clamp-2">
                            {projeto.descricao}
                          </CardDescription>
                        </div>

                        {projeto.tecnologias && projeto.tecnologias.length > 0 && (
                          <div className="flex flex-wrap gap-1">
                            {projeto.tecnologias.slice(0, 3).map((tech) => (
                              <Badge key={tech} variant="outline" className="text-xs">
                                {tech}
                              </Badge>
                            ))}
                            {projeto.tecnologias.length > 3 && (
                              <Badge variant="outline" className="text-xs">
                                +{projeto.tecnologias.length - 3}
                              </Badge>
                            )}
                          </div>
                        )}

                        <Link href={`/projetos/${projeto.slug}`}>
                          <Button className="w-full group/btn">
                            Ver Detalhes
                            <ExternalLink className="ml-2 h-4 w-4 group-hover/btn:translate-x-1 transition-transform" />
                          </Button>
                        </Link>
                      </CardContent>
                    </Card>
                  </ScrollReveal>
                ))}
              </div>
            )}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
