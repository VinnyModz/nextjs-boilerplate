import { NextResponse } from 'next/server';
import { getDatabase } from '@/lib/mongodb';
import { Project } from '@/lib/types';

export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url);
    const categoria = searchParams.get('categoria');
    const destaque = searchParams.get('destaque');

    const db = await getDatabase();
    const collection = db.collection<Project>('projetos');

    const filter: Record<string, unknown> = {};
    if (categoria && categoria !== 'todos') {
      filter.categoria = categoria;
    }
    if (destaque === 'true') {
      filter.destaque = true;
    }

    const projetos = await collection
      .find(filter)
      .sort({ createdAt: -1 })
      .toArray();

    return NextResponse.json(projetos);
  } catch (error) {
    console.error('[darkgzzh] Erro ao buscar projetos:', error);
    return NextResponse.json(
      { error: 'Erro ao buscar projetos' },
      { status: 500 }
    );
  }
}

export async function POST(request: Request) {
  try {
    const body = await request.json();
    
    const db = await getDatabase();
    const collection = db.collection<Project>('projetos');

    const projeto: Project = {
      ...body,
      createdAt: new Date(),
      updatedAt: new Date(),
    };

    const result = await collection.insertOne(projeto);

    return NextResponse.json(
      { id: result.insertedId, ...projeto },
      { status: 201 }
    );
  } catch (error) {
    console.error('[darkgzzh] Erro ao criar projeto:', error);
    return NextResponse.json(
      { error: 'Erro ao criar projeto' },
      { status: 500 }
    );
  }
}
