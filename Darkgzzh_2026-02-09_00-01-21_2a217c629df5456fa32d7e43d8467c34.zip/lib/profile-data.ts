import { ProfileData } from './types';

export const profileData: ProfileData = {
  nick: 'darkgzzh',
  nome: 'darkgzzh',
  titulo: 'Desenvolvedor Full Stack',
  bio: 'Desenvolvedor apaixonado por tecnologia e inovação, especializado em criar soluções modernas e funcionais para web.',
  bioCompleta: `Sou desenvolvedor apaixonado por programação e pela criação de soluções modernas e funcionais para a web. Atuo no desenvolvimento de aplicações escaláveis, sempre seguindo boas práticas e utilizando tecnologias atuais.

Tenho experiência com JavaScript, Python, Next.js e MongoDB. Gosto de transformar ideias em sistemas práticos e eficientes, com foco em desempenho, organização e design limpo.

Estou sempre em busca de evolução, aprendizado contínuo e da entrega de projetos que realmente façam a diferença.`,
  avatar: '/avatar.jpg',
  disponivel: true,
  links: {
    github: 'https://github.com/darkgzzh',
    discord: 'https://discord.com/users/409698127218475008',
  },
  tecnologias: [
    'JavaScript',
    'Python',
    'Next.js',
    'MongoDB',
    'TypeScript',
    'HTML',
    'CSS',
  ],
};
