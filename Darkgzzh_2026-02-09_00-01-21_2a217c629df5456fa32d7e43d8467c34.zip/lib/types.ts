export interface Project {
  _id?: string;
  nome: string;
  slug: string;
  descricao: string;
  descricaoCompleta?: string;
  categoria: 'bot' | 'website' | 'api';
  tecnologias: string[];
  imagens?: string[];
  linkGithub?: string;
  linkDemo?: string;
  linkExterno?: string;
  destaque?: boolean;
  dataInicio?: string;
  dataFim?: string;
  status?: 'concluido' | 'em-andamento' | 'pausado';
  createdAt?: Date;
  updatedAt?: Date;
}

export interface ProfileData {
  nick: string;
  nome: string;
  titulo: string;
  bio: string;
  bioCompleta: string;
  avatar: string;
  disponivel: boolean;
  links: {
    github?: string;
    discord?: string;
    linkedin?: string;
    email?: string;
  };
  tecnologias: string[];
}
