DISPLAY_NAME=Darkgzzh
MEMORY=512
VERSION=recommended
AUTORESTART=true
MAIN=app/page.tsx
START=npm run start
SUBDOMAIN=darkgzzh