import { Database } from 'lucide-react';
import { 
  SiJavascript, 
  SiTypescript, 
  SiNodedotjs, 
  SiNextdotjs, 
  SiMongodb, 
  SiPython 
} from 'react-icons/si';

interface TechItem {
  name: string;
  icon: React.ComponentType<{ className?: string }>;
  category: string;
  color: string;
}

const techStack: TechItem[] = [
  {
    name: 'JavaScript',
    icon: SiJavascript,
    category: 'Linguagem',
    color: 'text-yellow-400',
  },
  {
    name: 'TypeScript',
    icon: SiTypescript,
    category: 'Linguagem',
    color: 'text-blue-500',
  },
  {
    name: 'Node.js',
    icon: SiNodedotjs,
    category: 'Runtime',
    color: 'text-green-500',
  },
  {
    name: 'Next.js',
    icon: SiNextdotjs,
    category: 'Framework',
    color: 'text-foreground',
  },
  {
    name: 'MongoDB',
    icon: SiMongodb,
    category: 'Banco de Dados',
    color: 'text-green-500',
  },
  {
    name: 'Python',
    icon: SiPython,
    category: 'Linguagem',
    color: 'text-blue-400',
  },
];

export function TechStack() {
  return (
    <div className="flex flex-wrap gap-3 justify-center">
      {techStack.map((tech) => {
        const Icon = tech.icon;
        
        return (
          <div
            key={tech.name}
            className="group relative inline-flex items-center gap-2 px-4 py-2.5 bg-card/50 border border-border rounded-full hover:border-primary/50 hover:bg-card transition-all duration-300 hover:shadow-lg hover:-translate-y-0.5 cursor-default"
          >
            <Icon className={`w-5 h-5 ${tech.color} transition-transform duration-300 group-hover:scale-110`} />
            <span className="font-medium text-sm text-foreground/90 group-hover:text-foreground transition-colors">
              {tech.name}
            </span>
            
            <div className="absolute -top-8 left-1/2 -translate-x-1/2 px-2 py-1 bg-popover border border-border rounded text-xs text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity duration-200 pointer-events-none whitespace-nowrap">
              {tech.category}
            </div>
          </div>
        );
      })}
    </div>
  );
}