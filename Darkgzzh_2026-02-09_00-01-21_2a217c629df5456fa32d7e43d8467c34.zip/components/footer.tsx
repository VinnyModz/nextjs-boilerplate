import { profileData } from '@/lib/profile-data';
import { Github, MessageCircle } from 'lucide-react';

export function Footer() {
  const currentYear = new Date().getFullYear();

  return (
    <footer className="border-t border-border/50 bg-muted/30">
      <div className="container mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="flex flex-col md:flex-row items-center justify-between gap-6">
          <div className="text-sm text-muted-foreground text-center md:text-left">
            <span>© {currentYear} {profileData.nick}. Todos os direitos reservados.</span>
          </div>

          <div className="flex items-center gap-6">
            {profileData.links.github && (
              <a
                href={profileData.links.github}
                target="_blank"
                rel="noopener noreferrer"
                className="group flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
                aria-label="GitHub"
              >
                <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary/10 group-hover:bg-primary/20 transition-colors">
                  <Github className="h-5 w-5" />
                </div>
                <span className="font-medium">GitHub</span>
              </a>
            )}

            {profileData.links.discord && (
              <a
                href={profileData.links.discord}
                target="_blank"
                rel="noopener noreferrer"
                className="group flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground transition-colors"
                aria-label="Discord"
              >
                <div className="flex items-center justify-center w-10 h-10 rounded-full bg-primary/10 group-hover:bg-primary/20 transition-colors">
                  <MessageCircle className="h-5 w-5" />
                </div>
                <span className="font-medium">Discord</span>
              </a>
            )}
          </div>
        </div>
      </div>
    </footer>
  );
}
