import { MongoClient } from 'mongodb';

const uri = process.env.MONGODB_URI || '';

if (!uri) {
  throw new Error('MONGODB_URI não definido');
}

const projetosExemplo = [
  {
    nome: 'Site da Strong Applications',
    slug: 'site-strong-applications',
    descricao: 'Site para venda e gerenciamento de bots utilizando a SDK da Square Cloud.',
    descricaoCompleta: `Plataforma web desenvolvida para a venda e gerenciamento de bots Discord. O site conta com sistema de login via Discord, permitindo que usuários autentiquem suas contas de forma segura e acessem seus bots vinculados.

A aplicação utiliza a SDK da Square Cloud para realizar o gerenciamento completo dos bots, incluindo visualização de aplicações e controle de status com a plataforma de hospedagem. Todos os dados de usuários, bots e configurações são armazenados em um banco de dados MongoDB, garantindo persistência, escalabilidade e segurança.

O projeto foi desenvolvido com foco em performance, usabilidade e arquitetura moderna, oferecendo uma interface rápida, responsiva e intuitiva para facilitar o gerenciamento e a comercialização de bots.`,
    categoria: 'sites' as const,
    tecnologias: [
      'Next.js',
      'React',
      'TypeScript',
      'Node.js',
      'MongoDB',
      'Tailwind CSS',
    ],
    linkDemo: 'https://strongapplications.online/',
    imagens: ['/projetos/strongsite.jpg'],
    destaque: true,
    status: 'concluido' as const,
    dataInicio: '2026-01-14',
    dataFim: '2026-01-27',
    createdAt: new Date('2026-01-14'),
    updatedAt: new Date('2026-01-27'),
  },
];

async function seed() {
  const client = new MongoClient(uri);

  try {
    await client.connect();
    console.log('Conectado ao MongoDB');

    const db = client.db('portfolio');
    const collection = db.collection('projetos');

    await collection.deleteMany({});
    console.log('Coleção projetos limpa');

    const result = await collection.insertMany(projetosExemplo);
    console.log(`[darkgzzh] ${result.insertedCount} projetos inseridos`);

    console.log('Seed concluído com sucesso!');
  } catch (error) {
    console.error('Erro no seed:', error);
    process.exit(1);
  } finally {
    await client.close();
  }
}

seed();
